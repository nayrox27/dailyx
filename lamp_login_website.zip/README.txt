Interactive Lamp Login website

Upload index.html to the root of a GitHub repository, then enable GitHub Pages from Settings > Pages > Deploy from a branch > main > /(root).
This is a frontend demo; real authentication requires a backend/auth provider.
